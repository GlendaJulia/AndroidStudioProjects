package com.example.tecsup.glendajuliapractica03;

public class SMS_Receiver {
}
