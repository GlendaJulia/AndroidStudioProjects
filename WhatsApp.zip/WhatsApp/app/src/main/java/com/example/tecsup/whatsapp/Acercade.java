package com.example.tecsup.whatsapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Acercade extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acercade);
    }
}
